import logo from '../logo.svg';
import { useState, useEffect } from 'react';
import './Create.css';
import Home from './Home.js';

export default function Create({update, addTask}) {
	let [title, setTitle] = useState("");
	let [date, setDate] = useState("");
	let [description, setDescription] = useState("");
	// let [task, setTask] = useState([]);
	// let [taskGroup, setTaskGroup] = useState([]);
	console.log('coco');
	const newTask = { title, date, description };

	function SaveCreate(e) {

		e.preventDefault();

		// let copyTaskGroup = [...taskGroup];
		// copyTaskGroup.push(newTask);

		// setTaskGroup(copyTaskGroup);
		console.log('newTask', newTask);
		
		// console.log(copyTaskGroup);
		
		setTitle("");
		setDate("");
		setDescription("");
		addTask(newTask);
		update(<Home update={update} />);
		// addTask({title, date});
	};

	

	

	return (
		// <>
		<main className='create-main'>
			<form>
				<div className='create-h1'>
					<h1 >Create a task</h1>
				</div>
				<div className='create-title-div'>
					<p>Title :</p>
					<input className='create-title-input' type="text" value={title} onChange={(e) => { setTitle(e.target.value) }} />
				</div>
				<div className='create-date-div'>
					<p>Due Date : </p>
					<input className='create-date-input' type="date" value={date} onChange={(e) => { setDate(e.target.value) }} />
				</div>
				<div className='create-description-div'>
					<p>Description : </p>
					<textarea type="text" value={description} onChange={(e) => { setDescription(e.target.value) }} />
				</div>
				<div className='create-buttons-div'>
					<button className='create-btn-cancel'>Cancel</button>
					<button className='create-btn-create-task' onClick={(e) => {SaveCreate(e)}}>Create Task</button>
				</div>

			</form>

		</main>
		// </>
	)
}
