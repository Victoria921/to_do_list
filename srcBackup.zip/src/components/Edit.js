import logo from '../logo.svg';
import {useState, useEffect} from 'react';
import './Edit.css';
import Create from './Create.js';
 
export default function Edit() {
	let [title, setTitle] = useState(localStorage.getItem('title'));
	let [date, setDate] = useState(localStorage.getItem('date'));
	let [description, setDescription] = useState(localStorage.getItem('description'));


	function SaveEdit() {
		localStorage.setItem('title', title);
		localStorage.setItem('date', date);
		localStorage.setItem('description', description);
		console.log(title, date, description);


	};


  return (
    <>
			<main className='edit-main'>
				<div className='edit-h1'>
				<h1 >Edit a task</h1>
				</div>
				<div className='edit-title-div'>
					<p>Title :</p>
					<input type="text" value={title} onChange={(e) => {setTitle(e.target.value)}}/>
				</div>
				<div className='edit-date-div'>
					<p>Due Date : </p>
					<input type="date" value={date} onChange={(e) => {setDate(e.target.value)}}/>
				</div>
				<div className='edit-description-div'>
					<p>Description : </p>
					<textarea type="text" value={description} onChange={(e) => {setDescription(e.target.value)}}/>
				</div>
				<div className='edit-buttons-div'>
					<button className='edit-btn-cancel'>Cancel</button>
					<input type='submit' value='Save' className='edit-btn-save-task'onClick={() => {SaveEdit()}}></input>

				</div>

			</main>
		</>
  )
}