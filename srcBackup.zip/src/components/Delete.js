import logo from '../logo.svg';
import {useState, useEffect} from 'react';
import './Delete.css';
 
export default function Delete() {
  return (
    <>
        {/* <main className='delete-main'> */}
        <div className='delete-h1'>
          <h1>Task delete</h1>
        </div>
        <div className='delete-div'>
          <div className='delete-title-date'>
            <p>Title</p>
            <p>dd/mm/yyyy</p>
          </div>
          <div className='delete-description'>
            <p>Peut-être avez-vous déjà consulté une page Web ou un document utilisant ce type d’écriture sans toutefois y avoir porté une attention particulière. Le lorem ipsum est un texte de substitution utilisé dans la conception graphique. Ce langage factice rassemble toutes les lettres de l’alphabet dans un court paragraphe. La répartition des caractères y est équitable pour que l’attention du lecteur soit portée sur l’aspect graphique du document, et non sur le contenu textuel. Plusieurs logiciels et applications de mise en page en ont d’ailleurs fait leur « faux texte » par défaut. </p>
          </div>
        </div>
        <div className='delete-buttons-div'>
          <button className='delete-btn-cancel'>Cancel</button>
          <button className='delete-btn-delete'>Delete</button>
        </div>
      {/* </main> */}
    </>
  )
}
 