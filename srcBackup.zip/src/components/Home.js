import { useState, useEffect } from 'react';
import './Home.css';
import Create from './Create.js';


// function CurrentTask(i) {
//   console.log('yo');

//   return (
//     <div key={i} className='Home-task-header'>
//       <h2 className='Home-task-header-state'>State</h2>
//       <h2 className='Home-task-header-title'>Title</h2>
//       <h2 className='Home-task-header-date'>Date</h2>
//       <h2 className='Home-task-header-actions'>Actions</h2>
//     </div>);




// }


export default function Home({update}) {

    const [taskGroup, setTaskGroup] = useState([]);
    // console.log('taskGroup', taskGroup);
    
    // const [newTask, setNewTask] = useState({ title: '', date: '' });
    // (tasks) ? copyTaskGroup = [...tasks] : [];
    
    const addTask = (newTask) => {
      
      let copyTaskGroup = [];
      copyTaskGroup.push(newTask);
      
      console.log('taskGroup', taskGroup);
      console.log(newTask);
      console.log('copytaskgroup', copyTaskGroup);
      
      
      
      // let copyTaskGroup=[...taskGroup];
      // copyTaskGroup.push(task);
      // setTaskGroup(copyTaskGroup);
    }
    useEffect(() => {
      setTaskGroup(<h1>Bonjour</h1>);

     return () => {};


    },[taskGroup]);
    console.log('taskgroups2', taskGroup);
    
    
    

    // <Create addTask={addTask}/>


  // let [task, setTask] = useState(CurrentTask());


  
  let returnTask = taskGroup.map((newTask,i) => {

    return (
        <div key={i} className='Home-task-header'>
          <h2 className='Home-task-header-state'>State</h2>
          <h2 className='Home-task-header-title'>{newTask.title}</h2>
          <h2 className='Home-task-header-date'>{newTask.date}</h2>
          <h2 className='Home-task-header-actions'>Actions</h2>
        </div>
    )
  })

  return (
    <>
      <main className='Home-main'>
        <div className='Home-create-btn-div'>
          <button className='Home-create-btn' onClick={() => {update(<Create update={update} addTask={addTask}/>)}}>Create Task</button>
        </div>
        <div className='Home-task-header'>
          <h2 className='Home-task-header-state'>State</h2>
          <h2 className='Home-task-header-title'>Title</h2>
          <h2 className='Home-task-header-date'>Date</h2>
          <h2 className='Home-task-header-actions'>Actions</h2>
        </div>
        <div className='Home-task-container'>
          {returnTask}
        </div>

      </main>
    </>
  )
}






  // let [taskGroup, setTaskGroup] = useState([]);

  // <Create addTask={addTask}/>
  // function addTask(copyTaskGroup) {
  //   for (let i = 0; i < copyTaskGroup.length; i++) {
  //     copyTaskGroup.map((title, date) => {
  //       return (
  //           <div key={i} className='Home-task-header'>
  //             <h2 className='Home-task-header-state'>State</h2>
  //             <h2 className='Home-task-header-title'>{title[i]}</h2>
  //             <h2 className='Home-task-header-date'>{date[i]}</h2>
  //             <h2 className='Home-task-header-actions'>Actions</h2>
  //           </div>
  //       )
  //     })
      
      
  //   }
    
    // let copyTaskGroup = [...taskGroup];

    // console.log('taskgroup', taskGroup);
    // copyTaskGroup.push(newTask);
    // setTaskGroup(copyTaskGroup);
  // }