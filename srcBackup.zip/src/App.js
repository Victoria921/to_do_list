import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import Header from './components/Header';
import Edit from './components/Edit';
import Create from './components/Create';
import Detail from './components/Detail';
import Delete from './components/Delete';
import Footer from './components/Footer';
import {useState, useEffect} from 'react';
 
export default function App() {
  const [display, setDisplay] = useState(null);
 
  const update = (component) => {
    if (component !== display) {
      setDisplay(component);
    }
  };
 
  return (
    <>
    <div className='App'>
      <Header />
      {/* <Home/> */}
      {/* <Create addTask={addTask}/> */}
      {display || <Home update={update} tasks={null} />}
      <Footer />
    </div>
    </>
  );
}